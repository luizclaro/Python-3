sudo apt update -y
sudo apt upgrade -y
sudo apt install git curl build-essential -y
sudo apt install gcc make default-libmysqlclient-dev libssl-dev -y
sudo apt install python3.10-full python3.10-dev -y